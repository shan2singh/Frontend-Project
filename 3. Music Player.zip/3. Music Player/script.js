const songList=[{category:"Poem",name:"Rashmirathi",link:"songs/rashmirathi.mp3"},{category:"Poem",name:"Chetak",link:"songs/chetak.mp3"},{category:"Paath",name:"Kaalbhairav Ashtakam",link:"songs/kaalbhairav ashtakam.mp3"},{category:"Paath",name:"Hanuman Chalisa",link:"songs/hanuman chalisa.mp3"},{category:"Paath",name:"Madalsa Upadesh",link:"songs/madalasa upadesh.mp3"},{category:"Paath",name:"Namami Shamishan",link:"songs/namami shamishan.mp3"},{category:"Geeta",name:"Chapter - 7",link:"songs/ch-07.mp3"},{category:"Geeta",name:"Chapter - 8",link:"songs/ch-08.mp3"},{category:"Geeta",name:"Chapter - 12",link:"songs/ch-12.mp3"}];

const body=document.querySelector("body");
const checkbox=document.getElementById("toggle");
const songCategory=document.getElementById("songs-category");
const songsInCategory=document.getElementById("category-songs");
const audio=new Audio();
const player=document.getElementById("player");
const playbtn=document.getElementById("play-btn");
const pausebtn=document.getElementById("pause-btn");
const timeline=document.getElementById("progress");
const timeDisplay=document.getElementById("timeDisplay");
const sound=document.getElementById("sound");
const volSlider=document.getElementById("vol-slider");
const prevSong=document.getElementById("prevSong");
const nextSong=document.getElementById("nextSong");
const newName=document.getElementById("newName");
const createList=document.getElementById("create-list");
const currList=document.getElementById("curr-list");
const allList=document.getElementById("all-list");
const addSong=document.getElementById("addTo");
const containers=document.querySelectorAll("#left-container, #mid-container, #right-container");
const texts=document.querySelectorAll("#category-songs, #curr-list, #all-list");

let currentSong=null;
let currentPlaylist=[];
let playlists=[];

checkbox.addEventListener("change",function()
{
    if(checkbox.checked)
    {
        body.style.background="#444444";
        containers.forEach(function(container)
        {
            container.style.backgroundColor="#B3B3B3";
        });
        texts.forEach(function(text)
        {
            text.style.color="#fff";
        });
    }
    else
    {
        body.style.background="aquamarine";
        containers.forEach((container)=>
        {
            container.style.backgroundColor="aqua";
        });
        texts.forEach((text)=>
        {
            text.style.color="#444444";
        });
    }
});

function formatTime(seconds)
{
    const minutes=Math.floor(seconds/60);
    const remainingTime=Math.floor(seconds%60);
    return `${minutes}:${remainingTime.toString().padStart(2,"0")}`;
}

audio.addEventListener("timeupdate",()=>
{
    if(!isNaN(audio.duration))
    {
        timeline.value=(audio.currentTime/audio.duration)*100;
        const currentTime=formatTime(audio.currentTime);
        const duration = formatTime(audio.duration);
        timeDisplay.innerText = `${currentTime} / ${duration}`;
    }
})

function playSong(song)
{
    currentSong=song;
    audio.src = song.link;
    audio.play();
}

playbtn.addEventListener("click",()=>
{
    audio.play();
});

pausebtn.addEventListener("click",()=>
{
    audio.pause();
});

volSlider.addEventListener("input",()=>
{
    audio.volume=volSlider.value/100;
});

timeline.addEventListener("input",()=>
{
    audio.currentTime=(timeline.value/100)*audio.duration;
});

songCategory.addEventListener("change",()=>
{
    const selectedCategory=songCategory.value;
    const filteredSongs=songList.filter((song)=>
    {
        if(selectedCategory==="all")
        {
            return true;
        }
        return song.category.toLowerCase()===selectedCategory;
    });
    songsInCategory.innerHTML=`<h2>${selectedCategory==="all"?"All Songs":selectedCategory}</h2>`;
    filteredSongs.forEach((song)=>
    {
        const songElement=document.createElement('div');
        songElement.innerText=song.name;
        songsInCategory.append(songElement);
        songElement.style.backgroundColor="#12E193";
        songElement.style.height="2rem";
        songElement.style.display="flex";
        songElement.style.alignItems="center";
        songElement.style.justifyContent="center";
        songElement.style.width="80%";
        songElement.style.margin="5% 10% 5% 10%";
        songElement.style.cursor="pointer";
        songElement.addEventListener("click",()=>
        {
            playSong(song);
            player.innerHTML=song.name.toUpperCase();
            player.style.display="flex";
            player.style.alignItems="center";
            player.style.justifyContent="center";
        });
    });
});

createList.addEventListener("click",()=>
{
    const playlistName=newName.value.trim();
    if(playlistName==="")
    {
        alert("Enter playlist name");
        return;
    }
    const playlist={name:playlistName,songs:[]};
    playlists.push(playlist);
    const playlistElement = document.createElement("div");
    playlistElement.innerText=playlist.name;
    playlistElement.style.backgroundColor="#12e193";
    playlistElement.style.height="2rem";
    playlistElement.style.width="80%";
    playlistElement.style.margin="5% 10%";
    playlistElement.style.display="flex";
    playlistElement.style.justifyContent="center";
    playlistElement.style.alignItems="center";
    playlistElement.style.cursor="pointer";
    allList.appendChild(playlistElement);
    playlistElement.addEventListener("click",()=>
    {
        currentPlaylist=playlist;
        displayCurrentPlaylist();
    });
    newName.value="";
});

addSong.addEventListener("click",()=>
{
    if(currentSong===null)
    {
        alert("Please select a song first");
        return;
    }
    if(currentPlaylist===null)
    {
        alert("Please select a playlist first");
        return;
    }
    currentPlaylist.songs.push(currentSong);
    displayCurrentPlaylist();
});

function displayCurrentPlaylist()
{
    currList.innerHTML = "";
    const heading = document.createElement("h3");
    heading.innerText = currentPlaylist.name;
    currList.appendChild(heading);
    currentPlaylist.songs.forEach((song) => 
    {
        const songElement = document.createElement("div");
        songElement.innerText = song.name;
        songElement.style.backgroundColor = "#12E193";
        songElement.style.height = "2rem";
        songElement.style.width = "80%";
        songElement.style.margin = "5% 10%";
        songElement.style.display = "flex";
        songElement.style.justifyContent = "center";
        songElement.style.alignItems = "center";
        songElement.style.cursor = "pointer";
        currList.appendChild(songElement);
        songElement.addEventListener("click",()=> 
        {
            playSong(song);
        });
    });
}
