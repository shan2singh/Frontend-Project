let str="The Vedas stand as human history's oldest and most comprehensive encyclopedic ecosystem of knowledge, seamlessly uniting profound spiritual metaphysics with advanced empirical sciences. Originating from the Sanskrit root Vid, meaning - to know, this vast corpus is divided into four primary texts—the Rigveda, Samaveda, Yajurveda, and Atharvaveda—which together map out the cosmic, societal, and physical laws of existence. Far from being simple spiritual hymns, the broad scope of Vedic literature encompasses the six Vedangas and four Upavedas, detailing sophisticated systems of medicine (Ayurveda), advanced mathematics and geometry (Sulba Sutras), astronomy (Jyotisha), phonetics, and architecture. This ancient wisdom calculated planetary movements with staggering precision and laid the groundwork for linguistic structures and holistic healthcare thousands of years before the advent of modern western science. Ultimately culminating in the philosophical depths of the Upanishads (Vedanta), the Vedas bridge the gap between material science and inner consciousness, asserting that the individual mind is deeply interconnected with the universe. Today, this holistic heritage remains a timeless blueprint for human advancement, proving that scientific inquiry and spiritual growth are not opposing forces, but two sides of the same coin.";

const startBtn=document.getElementById("start-btn");
const typeText=document.getElementById("sentence");
const inputText=document.getElementById("input");
const timerElement=document.getElementById("timer");
const result=document.getElementById("result");
const speed=document.getElementById("speed");
const accuracy=document.getElementById("accuracy");
const retryBtn=document.getElementById("retry-btn");

let totalTime=30;
let timeLeft=totalTime;
let wordCount=0;
let mistakes=0;

startBtn.addEventListener("click",()=>
{
    typeText.innerText=str;
    inputText.disabled=false;
    inputText.focus();
    timer=setInterval(()=>
    {
        timeLeft--;
        let seconds=timeLeft%60; 
        let minutes=Math.floor(timeLeft/60);
        timerElement.textContent=`${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;
        if(timeLeft<=0)
        {
            endTest();
        }
    },1000);
});

function endTest()
{
    clearInterval(timer);
    inputText.disabled=true;
    startBtn.disabled=true;
    retryBtn.disabled=false;
    result.style.display="block";
    testResult();
}

function testResult()
{
    let inputStr=inputText.value;
    
    for(let i=0;i<inputStr.length;i++)
    {
        if(inputStr.charAt(i)===' ')
        {
            wordCount++;
        }
        if(inputStr.charAt(i)!==str.charAt(i))
        {
            mistakes++;
        }
    }
    wordCount++;
    let acc=(mistakes/inputStr.length)*100;
    accuracy.innerText=`${100-acc}`;
    speedCount();
    timeLeft=totalTime;
    wordCount=0;
    mistakes=0;
}

function speedCount()
{
    let typeSpeed=(wordCount*60)/totalTime;
    speed.innerText=`${typeSpeed.toFixed(2)}`;
}

retryBtn.addEventListener("click", () => 
{
    clearInterval(timer);
    timeLeft = totalTime;
    typeText.textContent = "";
    inputText.value = "";
    inputText.disabled = true;
    startBtn.disabled = false;
    result.style.display = "none";
    timerElement.textContent = "00:30";
});