console.log("JavaScript file loaded!");
const url="https://dummyjson.com/products/";
let cart=new Map();

function getProducts(url)
{
    return fetch(url).then((response)=>
    {
        if(!response.ok)
        {
            throw new Error("Product not found!");
        }
        return response.json();
    });
}

function displayProducts()
{
    getProducts(url).then((data)=>
    {
        const products=data.products;
        products.forEach((product)=> 
        {
            cart.set(product.id,{product:product,quantity:1});
            const productDiv=document.createElement("div");
            productDiv.classList.add("product");
            productDiv.innerHTML = `
                    <div class="img_con">
                        <img src="${product.thumbnail}" alt="${product.title}">
                    </div>
                    <div class="card_footer">
                        <h3>${product.title}</h3>
                        <p>Price: $${product.price}</p>
                        <p>Category: ${product.category}</p>
                        <button class="addToCartBtn">
                            Add to Cart
                        </button>
                    </div>
                `;
            const addBtn=productDiv.querySelector(".addToCartBtn");
            addBtn.addEventListener("click",()=>
            {
                if(cart.has(product.id))
                {
                    cart.get(product.id).quantity++;
                }
                else
                {
                    cart.set(product.id,{product:product,quantity:1});
                }
            });
            document.querySelector(".products").appendChild(productDiv);
        });
    }).catch((error)=>
    {
        console.log(error);
    })
}
displayProducts();

const cartBtn=document.getElementById("cartBtn");
const checkout=document.getElementById("checkoutBtn");
const cartContent=document.getElementById("cart");

cartBtn.addEventListener("click",()=> 
{
    cartContent.classList.toggle("show");
    displayCart();
});

checkout.addEventListener("click",()=> 
{
    cartContent.classList.add("show");
    displayCart();
});

function displayCart() 
{
    cartContent.innerHTML="<h2>Cart</h2>";
    cart.forEach((item,id) => 
    {
        const product=item.product;
        const productDiv=document.createElement("div");
        productDiv.classList.add("cart_item");
        productDiv.innerHTML=`
            <span>${product.title}</span>
            <span>$${product.price}</span>
            <span>Quantity: ${item.quantity}</span>
            <button class="decreaseBtn">-</button>
        `;
        const decreaseBtn=productDiv.querySelector(".decreaseBtn");
        decreaseBtn.addEventListener("click",()=> 
        {
            if (item.quantity>1) 
            {
                item.quantity--;
            } 
            else 
            {
                cart.delete(id);
            }
            displayCart();
        });
        cartContent.appendChild(productDiv);
    });
}