console.log("JavaScript file loaded!");
const url="https://pokeapi.co/api/v2/pokemon/";
const fight=document.getElementById("fight");

function getPokemon(url)
{
    return fetch(url).then((response)=>
    {
        if(!response.ok)
        {
            throw new Error("Pokemon not found!");
        }
        const jsonResponse=response.json();
        return jsonResponse;
    });
}

function getDetails(id1,id2)
{
    if(id1===id2)
    {
        return;
    }
    getPokemon(`${url}${id1}`)
    .then((pokemon1)=>
    {
        return getPokemon(`${url}${id2}`).then((pokemon2)=>
        {
            choosePokemon(pokemon1,pokemon2);
        });
    });
}

function choosePokemon(data1,data2)
{
    const abilities1=data1.abilities.map((item)=>
    {
        return `<li>${item.ability.name}</li>`;
    }).join("");
    const abilities2=data2.abilities.map((item)=>
    {
        return `<li>${item.ability.name}</li>`;
    }).join("");
    const pokemon=`<div id="player1">
                <div id="card_header">
                    <span id="p1_name"></span>
                    <span id="p1_score"></span>
                </div>
                <div id="card1">
                    <div id="img"><img src="${data1.sprites.front_default}"></div>
                    <span id="name">${data1.name}</span>
                    <span id="experience">${data1.base_experience}</span>
                    <ul id="abilities">
                        Abilities
                        ${abilities1}
                    </ul>
                </div>
            </div>
            <div id="player2">
                <div id="card_header">
                    <span id="p2_name"></span>
                    <span id="p2_score"></span>
                </div>
                <div id="card2">
                    <div id="img"><img src="${data2.sprites.front_default}"></div>
                    <span id="name">${data2.name}</span>
                    <span id="experience">${data2.base_experience}</span>
                    <ul id="abilities">
                        Abilities
                        ${abilities2}
                    </ul>
                </div>
            </div>`
    document.getElementById("container").innerHTML=pokemon;
}

fight.addEventListener("click",(data1,data2)=>
{
    const id1=Math.floor(Math.random()*20);
    const id2=Math.floor(Math.random()*20);
    getDetails(id1,id2);
});