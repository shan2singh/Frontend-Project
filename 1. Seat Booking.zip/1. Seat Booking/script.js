const moviesList=[{movieName:"Flash",price:7},{movieName:"Spiderman",price:5},{movieName:"Batman",price:4},];

const selectMovie=document.getElementById("selectMovie");
const movieNameEl=document.getElementById("movieName");
const moviePriceEl=document.getElementById("moviePrice");
const totalPriceEl=document.getElementById("totalPrice");
const selectedSeatsHolder=document.getElementById("selectedSeatsHolder");
const numberOfSeatEl=document.getElementById("numberOfSeat");
const proceedBtn=document.getElementById("proceedBtn");
const cancelBtn=document.getElementById("cancelBtn");
const seats=document.querySelectorAll("#seatCont .seat");

let currentMovie=moviesList[0];
let selectedSeats=[];

moviesList.forEach((movie,index)=>
{
    const option=document.createElement('option');
    option.value=index;
    option.textContent=`${movie.movieName} ($${movie.price})`;
    selectMovie.appendChild(option);
});

selectMovie.addEventListener('change',(e)=>
{
    const movie=moviesList[e.target.value];
    currentMovie=movie;
    movieNameEl.textContent=movie.movieName;
    moviePriceEl.textContent=`$ ${movie.price}`;
    updateTotal();
});

seats.forEach((seat,index)=>
{
    if(seat.classList.contains('occupied'))
    {
        return;
    }
    seat.addEventListener('click',()=>
    {
        if(seat.classList.contains('selected'))
        {
            seat.classList.remove('selected');
            selectedSeats=selectedSeats.filter((s)=>s!==index);
        }
        else
        {
            seat.classList.add('selected');
            selectedSeats.push(index);
        }
        updateSeatHolder();
        updateTotal();
    });
});

function updateSeatHolder()
{
    selectedSeatsHolder.innerHTML='';

    if(selectedSeats.length===0)
    {
        const span=document.createElement('span');
        span.classList.add('noSelected');
        span.textContent="No Seat Selected";
        selectedSeatsHolder.appendChild(span);
    }
    else
    {
        selectedSeats.forEach((i)=>
        {
            const seatTag=document.createElement('span');

            seatTag.textContent=`Seat ${i+1}`;
            seatTag.classList.add('selectedSeat');
            selectedSeatsHolder.appendChild(seatTag);
        });
    }
    numberOfSeatEl.textContent=selectedSeats.length;
}

function updateTotal()
{
    const total=selectedSeats.length*currentMovie.price;
    totalPriceEl.textContent=`$${total}`;
}

proceedBtn.addEventListener('click',()=>
{
    if(selectedSeats.length===0)
    {
        alert('Oops! No Selection Found');
        return;
    }
    alert('Congratulations! for Successful Booking');
    seats.forEach((seat,index)=>
    {
        if(selectedSeats.includes(index))
        {
            seat.classList.remove('selected');
            seat.classList.add('occupied');
        }
    });
    selectedSeats=[];
    updateSeatHolder();
    updateTotal();
});

cancelBtn.addEventListener('click',()=>
{
    seats.forEach((seat)=>
    {
        seat.classList.remove('selected');
    });
    selectedSeats=[];
    updateSeatHolder();
    updateTotal();
});