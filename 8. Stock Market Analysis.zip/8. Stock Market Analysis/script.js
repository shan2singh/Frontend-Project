console.log("JavaScript file loaded!");

const urlData ="https://stock-market-api-k9vl.onrender.com/api/stocksdata/";
const urlStats ="https://stock-market-api-k9vl.onrender.com/api/stocksstatsdata";
const urlProfile ="https://stock-market-api-k9vl.onrender.com/api/profiledata";

let stockData;
let statsData;
let profileData;
let selectedStock = "AAPL";
let selectedRange = "1year";
let stockChart;

function getData(url) 
{
    return fetch(url).then(response => 
    {
        if (!response.ok) 
        {
            throw new Error(`Request failed: ${response.status}`);
        }
        return response.json();
    });
}

function escapeHTML(value) 
{
    return String(value ?? "").replace(/[&<>"']/g, character => 
    {
        const entities = 
        {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };
        return entities[character];
    });
}

function findSymbolData(data, symbol) 
{
    if (!data || typeof data !== "object") 
    {
        return undefined;
    }
    if (Object.prototype.hasOwnProperty.call(data, symbol)) 
    {
        return data[symbol];
    }
    const children=Array.isArray(data)?data:Object.values(data);
    for (const child of children) 
    {
        const result = findSymbolData(child, symbol);
        if (result !== undefined) 
        {
            return result;
        }
    }
    return undefined;
}

function getHistoricalRecords(symbol, range = selectedRange) 
{
    const stock = stockData?.stocksData?.[0]?.[symbol];
    if (!stock) 
    {
        console.error("Stock not found:", symbol);
        return [];
    }
    const periodAliases = 
    {
        "1month": ["1mo", "1m", "1month"],
        "3month": ["3mo", "3m", "3month"],
        "1year": ["1y", "1yr", "1year"],
        "5year": ["5y", "5yr", "5year"]
    };
    const periodKey = periodAliases[range]?.find(key =>
        stock[key] &&
        Array.isArray(stock[key].timeStamp) &&
        Array.isArray(stock[key].value)
    );
    if (!periodKey) 
    {
        console.error(
            `Historical data for ${range} is unavailable.`,
            "Available periods:",
            Object.keys(stock)
        );
        return [];
    }
    const historical = stock[periodKey];
    const records = historical.timeStamp
        .map((timestamp, index) => 
        ({
            date: new Date(Number(timestamp) * 1000),
            value: Number(historical.value[index])
        }))
        .filter(record =>
            Number.isFinite(record.date.getTime()) &&
            Number.isFinite(record.value)
        );
    records.sort((a, b) => a.date - b.date);
    console.log(
        `${symbol} (${range}): ${records.length} records`
    );
    return records;
}

async function loadData() 
{
    try 
    {
        const [data, stats, profile] = await Promise.all([
            getData(urlData),
            getData(urlStats),
            getData(urlProfile)
        ]);
        stockData = data;
        statsData = stats;
        profileData = profile;
        console.log("Stock data keys:", Object.keys(stockData));
        console.log("Complete stock data:", stockData);
        console.log("AAPL historical data:",findSymbolData(stockData, "AAPL"));
        console.log("Stock Data:", stockData);
        console.log("Statistics:", statsData);
        console.log("Profile:", profileData);
        displayStocks(profileData);
        selectStock(selectedStock);
    } 
    catch (error) 
    {
        console.error("Error loading stock data:", error);
        document.getElementById("profile-container").textContent ="Unable to load stock data. Please try again later.";
    }
}

function displayStocks(profiles) 
{
    const container = document.getElementById("stocks");
    container.innerHTML = "";
    console.log("Received profiles:", profiles);
    const stockProfiles=profiles?.stocksProfileData??profiles?.stockProfileData;
    console.log("Stock profiles:", stockProfiles);
    const profileObject = Array.isArray(stockProfiles)?stockProfiles[0]:stockProfiles;
    if (!profileObject || typeof profileObject !== "object") 
    {
        console.error("Unexpected profile API structure:", profiles);
        container.textContent = "Stock list unavailable.";
        return;
    }
    const symbols = Object.keys(profileObject).filter(symbol =>
        profileObject[symbol] !== null &&
        typeof profileObject[symbol] === "object"
    );
    console.log("Extracted symbols:", symbols);
    if (symbols.length === 0) 
    {
        container.textContent = "No stocks found.";
        return;
    }
    symbols.forEach(symbol => 
    {
        const card = document.createElement("div");
        card.className = "stock-item";
        card.textContent = symbol;
        card.addEventListener("click", () => 
        {
            selectStock(symbol);
        });
        container.appendChild(card);
    });
}

function selectStock(symbol) 
{
    selectedStock = symbol;
    const profile = findSymbolData(profileData, symbol);
    if (profile && typeof profile === "object") 
    {
        displayProfile(
        {
            symbol: symbol,
            summary: profile.summary
        });
    }
    const stats = findSymbolData(statsData, symbol);
    displayStats(stats);
    const records = getHistoricalRecords(symbol);
    console.log("Records found:", records.length);
    console.log("First two records:", records.slice(0, 2));
    const result = filterStockData(records, selectedRange);
    console.log("Filtered labels:", result.labels);
    console.log("Filtered prices:", result.prices);
    drawGraph(result.labels, result.prices, symbol);
}

function displayProfile(profile) 
{
    const container = document.getElementById("profile-container");
    container.innerHTML = `
        <h3>${escapeHTML(profile.symbol)}</h3>
        <p>${escapeHTML(profile.summary || "No summary available.")}</p>
        <div id="stats-container"></div>
    `;
}

function displayStats(stats) 
{
    const container = document.getElementById("stats-container");
    if (!container) 
    {
        return;
    }
    if (!stats || typeof stats !== "object") 
    {
        container.textContent = "Statistics unavailable.";
        return;
    }
    const entries = Object.entries(stats).filter(
        ([, value]) =>
            value === null || ["string","number","boolean"].includes(typeof value)
    );
    if (entries.length === 0) 
    {
        container.textContent = "No statistics available.";
        return;
    }
    container.innerHTML = entries.map(([key, value]) => `
        <p>
            <strong>${escapeHTML(key)}:</strong>
            ${escapeHTML(value ?? "N/A")}
        </p>
    `).join("");
}

function filterStockData(historicalRecords, range) 
{
    if (!historicalRecords || historicalRecords.length === 0)
    {
        return {
            labels: [],
            prices: []
        };
    }
    const latestDate = new Date(
        historicalRecords[historicalRecords.length - 1].date
    );
    const startDate = new Date(latestDate);
    if (range === "1month") 
    {
        startDate.setMonth(startDate.getMonth() - 1);
    } 
    else if (range === "3month") 
    {
        startDate.setMonth(startDate.getMonth() - 3);
    } 
    else if (range === "1year") 
    {
        startDate.setFullYear(startDate.getFullYear() - 1);
    }
    else if (range === "5year")
    {
        startDate.setFullYear(startDate.getFullYear() - 5);
    }
    const filteredRecords = historicalRecords.filter(record => 
    {
        const recordDate = new Date(record.date);
        return recordDate >= startDate && recordDate <= latestDate;
    });
    return {
        labels: filteredRecords.map(record => record.date),
        prices: filteredRecords.map(record => record.value)
    };
}

function drawGraph(labels, prices, stockName) 
{
    const canvas = document.getElementById("stock-chart");
    if (!canvas) 
    {
        console.error("Canvas element #stock-chart was not found.");
        return;
    }
    const summaryContainer = document.getElementById("price-summary");
    const points = (prices ?? [])
        .map((price, index) => 
        ({
            price: Number(price),
            date: labels[index]
        }))
        .filter(point => Number.isFinite(point.price));

    if (summaryContainer) 
    {
        if (points.length === 0) 
        {
            summaryContainer.textContent =
                `No price data available for ${stockName} in ${selectedRange}.`;
        } 
        else 
        {
            const peak = points.reduce((highest, current) =>
                current.price > highest.price ? current : highest
            );
            const low = points.reduce((lowest, current) =>
                current.price < lowest.price ? current : lowest
            );
            const formatPrice = price =>
                "$" + price.toLocaleString("en-US", 
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            const formatDate = value => 
            {
                const date = new Date(value);
                return Number.isNaN(date.getTime())
                    ? "Date unavailable"
                    : date.toLocaleDateString("en-US", 
                    {
                        year: "numeric",
                        month: "short",
                        day: "numeric"
                    });
            };
            summaryContainer.innerHTML = `
                <div class="price-stat">
                    <span>Peak Price</span>
                    <strong>${formatPrice(peak.price)}</strong>
                    <small>${formatDate(peak.date)}</small>
                </div>

                <div class="price-stat">
                    <span>Lowest Price</span>
                    <strong>${formatPrice(low.price)}</strong>
                    <small>${formatDate(low.date)}</small>
                </div>
            `;
        }
    }
    if (stockChart) 
    {
        stockChart.destroy();
    }

    stockChart = new Chart(canvas.getContext("2d"), 
    {
        type: "line",
        data: 
        {
            labels: labels,
            datasets: 
            [{
                label: `${stockName} Price`,
                data: prices,
                borderColor: "#2563eb",
                backgroundColor: "rgba(37, 99, 235, 0.12)",
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.2,
                fill: true
            }]
        },
        options: 
        {
            responsive: true,
            maintainAspectRatio: false,
            interaction:
            {
                mode:"nearest",
                intersect:false
            },            
            plugins: 
            {
                tooltip:
                {
                    enabled:true,
                    mode:"nearest",
                    intersect:false,
                    callbacks:
                    {
                        title: function(items)
                        {
                            return "Date: "+items[0].label;
                        },
                        label:function(context)
                        {
                            return "Price: $"+context.parsed.y.toFixed(2);
                        }
                    }
                },
                legend: 
                {
                    display: true
                }
            },
            scales: 
            {
                x: 
                {
                    title: 
                    {
                        display: true,
                        text: "Date"
                    }
                },
                y: 
                {
                    title: 
                    {
                        display: true,
                        text: "Stock Price"
                    }
                }
            }
        }
    });
    if (labels.length === 0) 
    {
        console.warn(
            `No historical records found for ${stockName} in ${selectedRange}.`
        );
    }
}

const filterButtons = document.querySelectorAll("#time-filters button");

filterButtons.forEach(button => 
{
    button.addEventListener("click", () => 
    {
        selectedRange = button.dataset.range;
        console.log("Selected range:", selectedRange);
        const records = getHistoricalRecords(selectedStock);
        const result = filterStockData(records, selectedRange);
        drawGraph(result.labels, result.prices, selectedStock);
    });
});

loadData();