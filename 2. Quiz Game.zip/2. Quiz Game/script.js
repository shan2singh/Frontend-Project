let postsData = 
[
    { id: 1, author: 'John', content: 'Hello, Instagram!', likes: 10, comments: ['Great post!', 'Nice photo!'], image: 'https://files.codingninjas.in/image2-28694.jpg' },
    { id: 2, author: 'Jane', content: 'This is a great post!', likes: 15, comments: [], image: 'https://files.codingninjas.in/oip-28704.jpg' },
    { id: 3, author: 'Alice', content: 'Another post', likes: 8, comments: [], image: 'https://files.codingninjas.in/th-2-28706.jpg' },
    { id: 4, author: 'Bob', content: 'Check out this photo!', likes: 20, comments: [], image: 'https://files.codingninjas.in/image1-28708.jpg' },
];

const likedPosts = new Set();

// DOM references (matching scaffold IDs)
const postForm = document.getElementById('postForm');
const postInput = document.getElementById('postInput');
const imageInput = document.getElementById('imageInput');

function renderPosts() 
{
    const postsContainer = document.getElementById('posts');
    postsContainer.innerHTML = '';

    postsData.forEach((post) => 
    {
        const postElement = document.createElement('div');
        postElement.classList.add('post');
        const authorElement = document.createElement('h3');
        authorElement.textContent = post.author;
        const contentElement = document.createElement('p');
        contentElement.textContent = post.content;
        const imageElement = document.createElement('img');
        imageElement.src = post.image;
        imageElement.alt = 'Post Image';
        const likeButton = document.createElement('button');
        likeButton.textContent = `Like`;
        likeButton.classList.add('like-button');
        // If this post was liked earlier in the current session, reflect it
        if (likedPosts.has(post.id)) 
        {
            likeButton.disabled = true;
            likeButton.style.backgroundColor = 'red';
        }
        likeButton.addEventListener('click', () => 
        {
            if (!likedPosts.has(post.id)) 
            {
                likePost(post.id);
                likedPosts.add(post.id);
                likeButton.disabled = true;
                likeButton.style.backgroundColor = 'red';
            }
        });

        const commentInput = document.createElement('input');
        commentInput.type = 'text';
        commentInput.placeholder = 'Write a comment...';

        const commentButton = document.createElement('button');
        commentButton.textContent = 'Comment';
        commentButton.classList.add('comment-button');
        commentButton.addEventListener('click', () => 
        {
            addComment(post.id, commentInput.value);
            commentInput.value = '';
        });

        const postFooter = document.createElement('div');
        postFooter.classList.add('post-footer');
        postFooter.textContent = `Likes: ${post.likes}   Comments: ${post.comments.length}`;

        const commentsContainer = document.createElement('div');
        commentsContainer.classList.add('comments-container');
        commentsContainer.style.display = 'none';

        post.comments.forEach((comment) => 
        {
            const commentElement = document.createElement('p');
            commentElement.textContent = comment;
            commentsContainer.appendChild(commentElement);
        });

        postElement.appendChild(authorElement);
        postElement.appendChild(imageElement);
        postElement.appendChild(contentElement);
        postElement.appendChild(likeButton);
        postElement.appendChild(commentInput);
        postElement.appendChild(commentButton);
        postElement.appendChild(postFooter);
        postElement.appendChild(commentsContainer);

        postFooter.addEventListener('click', () => 
        {
            commentsContainer.style.display = commentsContainer.style.display === 'none' ? 'block' : 'none';
        });

        postsContainer.appendChild(postElement);
    });
}

    // Like handler
function likePost(postId) 
{
    const post = postsData.find((p) => p.id === postId);
    if (post) 
    {
        post.likes++;
        renderPosts();
    }
}

// Comment handler
function addComment(postId, comment) 
{
    const post = postsData.find((p) => p.id === postId);
    if (post && comment.trim()) 
    {
        post.comments.push(comment.trim());
        renderPosts();
    }
}

// Submit handler for creating a new post
postForm.addEventListener('submit', function (e) 
{
    e.preventDefault();

    // Try to get an author input if present in HTML; if missing, fallback to "Anonymous"
    const authorEl = document.getElementById('authorInput');
    const authorName = authorEl ? authorEl.value.trim() : 'Anonymous';

    const postContent = postInput.value.trim();
    const imageFile = imageInput.files && imageInput.files[0];

    // Basic validation: content and image are required (author optional)
    if (!postContent) 
    {
        alert('Please write a caption for your post.');
        return;
    }

    if (!imageFile) 
    {
        alert('Please select an image for your post.');
        return;
    }

    // Create temporary URL for the uploaded image
    const imageURL = URL.createObjectURL(imageFile);

    // Compute next id robustly (handles if postsData ids are not contiguous)
    const maxId = postsData.reduce((max, p) => Math.max(max, p.id), 0);
    const newPost={id:maxId+1,author:authorName||'Anonymous',content:postContent,likes:0,comments:[],image:imageURL,};

    postsData.push(newPost);

    // Debugging logs (optional)
    // console.log('New post added:', newPost);
    // console.log('Total posts now:', postsData.length);

    renderPosts();
    postForm.reset();
});

// Initial render
renderPosts();
